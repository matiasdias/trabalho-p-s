/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package avaliacao;

/**
 *
 * @author Erlanio
 */
public class Casamento extends Evento{

    private String noivo;
    private String noiva;

    public String getNoivo() {
        return noivo;
    }

    public void setNoivo(String noivo) {
        this.noivo = noivo;
    }

    public String getNoiva() {
        return noiva;
    }

    public void setNoiva(String noiva) {
        this.noiva = noiva;
    }

    String jogarBouque() {
        return this.noiva + " jogou o bouquê!";
    }
    
    @Override
    public String imprimirDados(){
        return "Parabéna ao casal: " + this.noivo + " e " + this.noiva;
    }
}
