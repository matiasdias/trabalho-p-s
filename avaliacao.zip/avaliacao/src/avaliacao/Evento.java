/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package avaliacao;

import java.util.Date;

/**
 *
 * @author Erlanio
 */
public class Evento implements BasicoDAO{
    private String nome;
    private Date dtInicio;
    private Date dtFim;
    private int maxInscricoes;

    
     public String imprimirDados(){
        return imprimirDados();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getDtInicio() {
        return dtInicio;
    }

    public void setDtInicio(Date dtInicio) {
        this.dtInicio = dtInicio;
    }

    public Date getDtFim() {
        return dtFim;
    }

    public void setDtFim(Date dtFim) {
        this.dtFim = dtFim;
    }

    public int getMaxInscricoes() {
        return maxInscricoes;
    }

    public void setMaxInscricoes(int maxInscricoes) {
        this.maxInscricoes = maxInscricoes;
    }

    @Override
    public void salvar(Object bean) {
       System.out.println("SALVAR");
      
       
    }

   
}
