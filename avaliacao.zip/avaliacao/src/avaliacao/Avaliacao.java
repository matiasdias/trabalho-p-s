/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package avaliacao;

import java.util.Date;

/**
 *
 * @author Erlanio
 */
public class Avaliacao {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        Conexao conn = new Conexao();
//        conn.createConnectionToMySQL();

        Casamento casamento1 = new Casamento();
        casamento1.setNome("Casamento do Ano");
        casamento1.setMaxInscricoes(400);
        casamento1.setDtInicio(new Date(2020, 05, 23, 16, 0, 0));
        casamento1.setDtFim(new Date(2020, 05, 23, 23, 0, 0));
        casamento1.setNoivo("João");
        casamento1.setNoiva("Carla");
        System.out.println(casamento1.imprimirDados());
        casamento1.salvar(casamento1);

        Aniversario aniversario1 = new Aniversario();
        aniversario1.setNome("Aniversário do mês");
        aniversario1.setMaxInscricoes(50);
        aniversario1.setDtInicio(new Date(2020, 05, 23, 16, 0, 0));
        aniversario1.setDtFim(new Date(2020, 05, 23, 23, 0, 0));
        aniversario1.setAniversariante("Marcos");
        System.out.println(aniversario1.imprimirDados());

    }

}
